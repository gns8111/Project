//////////////////id 중복검사//////////////////////////
function idCheck(id) {
	frm = document.regFrm;
	if(id==""){
		alert("아이디를 입력하세요.");
		frm.id.focus();
		return;//function을 벗어난다.
	}
	url = "idCheck.jsp?id="+id;
	window.open(url,"IDCheck","width=300,height=150");
}



//////////////글작성 유효성 검사///////////////////////
function writeCheck(){
	if(document.writeFrm.bTitle.value=""){
		alert("제목을 입력하세요.");
		document.writeFrm.bTitle.focus();
		return;
	}
	if(document.writeFrm.bContent.value=""){
		alert("내용을 입력하세요.");
		document.writeFrm.bContent.focus();
		return;
	}
	document.writeFrm.submit();
}

/////////////////회원가입 유효성 검사/////////////////////////////
function inputCheck(){
	if(document.regFrm.id.value==""){
		alert("아이디를 입력해 주세요.");
		document.regFrm.id.focus();
		return;
	}
	if(document.regFrm.pwd.value==""){
		alert("비밀번호를 입력해 주세요.");
		document.regFrm.pwd.focus();
		return;
	}
	if(document.regFrm.pwd2.value==""){
		alert("비밀번호를 확인해 주세요");
		document.regFrm.pwd2.focus();
		return;
	}
	if(document.regFrm.name.value==""){
		alert("이름을 입력하세요.");
		document.regFrm.name.focus();
		return;
	}
	if(document.regFrm.pwd.value != document.regFrm.pwd2.value){
		alert("비밀번호가 일치하지 않습니다.");
		document.regFrm.pwd2.value="";
		document.regFrm.pwd2.focus();
		return;
	}
	if(document.regFrm.email.value==""){
		alert("이메일을 입력해 주세요.");
		document.regFrm.email.focus();
		return;
	}

	document.regFrm.submit();
}

function win_close(){
	self.close();
}