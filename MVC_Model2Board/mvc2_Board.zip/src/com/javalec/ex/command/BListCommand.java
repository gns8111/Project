package com.javalec.ex.command;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.dao.BDao;
import com.javalec.ex.dto.BDto;

public class BListCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		//초기값으로 pageNum은 1이지만, 리퀘스트로 받은 값이 null아니라면 해당 값 초기화
		
		int pageNum = 1;
		if (request.getParameter("pageNum") != null) {
			pageNum = Integer.parseInt(request.getParameter("pageNum"));
		}
		
		System.out.println("bList페이지 pageNum: " + pageNum);
		BDao dao = new BDao();
		//pageNum을 인자 값으로 넘김
		ArrayList<BDto> dtos = dao.list(pageNum);
		
		request.setAttribute("list", dtos);
	}
}