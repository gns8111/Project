package com.javalec.ex.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.dao.BDao;
import com.javalec.ex.dto.BDto;

public class BContentCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		int bId = 0;
		if(request.getParameter("bId") == null){
			System.out.println("Ż��");
			return;
		}
		bId = Integer.parseInt(request.getParameter("bId"));
		BDao dao = new BDao();
		BDto dto = dao.contentView(Integer.toString(bId));
		request.setAttribute("content_view", dto);
		
		
		
	}

}
