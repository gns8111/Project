package com.javalec.ex.command;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import com.javalec.ex.dao.BDao;

public class BWriteCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		
		HttpSession session = request.getSession();
		String userID = (String)session.getAttribute("userID");
		String bTitle = request.getParameter("bTitle");
		request.setAttribute("bTitle", bTitle);
		String bContent = request.getParameter("bContent");
		
		if (session.getAttribute("userID") != null) {
			userID = (String) session.getAttribute("userID");
		}
		if(userID == null) {
			try {
				PrintWriter out = response.getWriter();
				out.println("<script> alert('�α��� �ϼ���.'); location.href = 'login.jsp';</script>");
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}else {
			if (bTitle.equals("") || bContent.equals("")) {
				response.setContentType("text/html; charset=UTF-8");
				System.out.println("null ����");
				try {
					PrintWriter out = response.getWriter();
					out.println("<script> alert('�Է����� ���� ������ �ֽ��ϴ�.'); history.back();</script>");
					out.close();
					return;
				
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}else { 	
				BDao dao = new BDao();
				
				dao.write(bTitle, bContent, userID);
			}
		}
	}
}
		
		
		
		
		
