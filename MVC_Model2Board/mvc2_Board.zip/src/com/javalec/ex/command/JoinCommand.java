package com.javalec.ex.command;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.dao.UserDAO;
import com.javalec.ex.dto.UserDTO;

public class JoinCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub

		
		String id = request.getParameter("id"); 
		String pwd = request.getParameter("pwd"); 
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String gender = request.getParameter("gender");
		 
		UserDTO bean = new UserDTO();
		bean.setUserID(id);
		bean.setUserPWD(pwd);
		bean.setUserName(name);
		bean.setUserEmail(email);
		bean.setUserGender(gender);
		
	    UserDAO dao = new UserDAO();
	    boolean result = dao.join(bean);
		
	    request.setAttribute("result", result);
	    
	    
	}
}
