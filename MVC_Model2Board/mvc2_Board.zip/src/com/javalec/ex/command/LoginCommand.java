package com.javalec.ex.command;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.dao.UserDAO;

public class LoginCommand implements BCommand{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
	
		String userID = request.getParameter("userID");
		String userPWD = request.getParameter("userPWD");
		UserDAO dao = new UserDAO();
		int result = dao.login(userID, userPWD);
		System.out.println(result);
		
		response.setContentType("text/html; charset=UTF-8");
		try {
			
			PrintWriter out = response.getWriter();
			if (result==0) {
				out.println("<script> alert('��й�ȣ�� Ʋ���ϴ�.'); history.back();</script>");

			}else if (result==-1) {
				out.println("<script> alert('�������� �ʴ� ID�Դϴ�.'); history.back();</script>");
				out.flush();

			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		 
		 
		
	
	}

}
