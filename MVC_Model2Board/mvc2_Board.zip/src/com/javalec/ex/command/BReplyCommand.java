package com.javalec.ex.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.dao.BDao;
import com.javalec.ex.dto.BDto;

public class BReplyCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		String userID = request.getParameter("userID");
		int bId = Integer.parseInt(request.getParameter("bId"));
		String bName = request.getParameter("RName");
		String bTitle = request.getParameter("bTitle");
		String bContent = request.getParameter("bContent");
		int bGroup = Integer.parseInt(request.getParameter("bGroup"));
		int bStep = Integer.parseInt(request.getParameter("bStep"));
		int bIndent = Integer.parseInt(request.getParameter("bIndent"));
		
		BDao dao = new BDao();
		
		/*BDto dto = new BDto();
		 * dto.setbId(bId); dto.setbName(bName); dto.setbTitle(bTitle);
		 * dto.setbContent(bContent); dto.setbGroup(bGroup); dto.setbStep(bStep);
		 * dto.setbIndent(bIndent); dto.setUserID(userID);
		 */
		dao.reply(bId, bName, bTitle, bContent, bGroup, bStep, bIndent, userID);
		
	}

}
