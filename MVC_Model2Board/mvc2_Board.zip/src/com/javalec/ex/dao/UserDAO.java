package com.javalec.ex.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import com.javalec.ex.dto.UserDTO;

public class UserDAO {
	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet rs;

	
//	private DataSource dataSource;
	
	public UserDAO() {
		try {
			/*"jdbc:mysql://127.0.0.1:3306/board?useUnicode=true&characterEncoding=UTF-8"*/
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String uid = "c##root";
			String upw = "1234";
			/*org.gjt.mm.mysql.Driver*/
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(url, uid, upw);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
//		try {
//			Context context = new InitialContext();
//			dataSource = (DataSource)context.lookup("java:comp/env/jdbc/Oracle11g");
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
	}
	
	//ȸ����� ��ü
	public ArrayList<UserDTO> memberSelect() {
		
		ArrayList<UserDTO> dtos = new ArrayList<UserDTO>();
		String sql = null;
		try {
			
//			con = dataSource.getConnection();
			sql = "select * from member";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				String userID = rs.getString("userID");
				String userPWD = rs.getString("userPWD");
				String userName = rs.getString("userName");
				String userGender = rs.getString("userGender");
				String userEmail = rs.getString("userEmail");
				
				
				UserDTO dto = new UserDTO(userID, userPWD, userName, userGender, userEmail);
				dtos.add(dto);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return dtos;
	}
	
	//�α���  (ID, PWD Ȯ��)
	public int login(String userID, String userPassword) {
		String sql = "select userPWD from member where userID=?";
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userID);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				if (rs.getString(1).equals(userPassword)) {
					return 1; //�α��� ����
				}else {
					return 0;//��й�ȣ Ʋ��
				}
			
			}
			return -1;//���̵� ����.
			
		} catch (Exception e) {
			e.printStackTrace();
		}	
		return 2;//�����ͺ��̽� ���� 
	}
	
	//ID �ߺ�Ȯ�� - true �ߺ�
		public boolean checkId(String id) {
			String sql = null;
			boolean flag = false;
			try {
				sql = "select userID from member where userID=?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, id);
				rs = pstmt.executeQuery();
				flag = rs.next();//������� ������ true ������ false
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if(rs != null) rs.close();
					if(pstmt != null) pstmt.close();
					if(con != null) con.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			return flag;
		}
		
	//ȸ������
	public boolean join(UserDTO bean) {
		
		String sql = null;
		boolean flag = false;
		
		try {
			sql = "insert into member(userID,userPWD,userNAME,userGender,userEmail) values(?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bean.getUserID());
			pstmt.setString(2, bean.getUserPWD());
			pstmt.setString(3, bean.getUserName());
			pstmt.setString(4, bean.getUserGender());
			pstmt.setString(5, bean.getUserEmail());
			int result = pstmt.executeUpdate();
			if (result == 1) {
				flag = true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return flag;//����
	}
}
