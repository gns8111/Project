package com.javalec.ex.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;


import com.javalec.ex.dto.BDto;

public class BDao {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;

	
//	DataSource dataSource;
	
	public BDao() {
		// TODO Auto-generated constructor stub
		
		//생성자에 드라이버 로드 = MySQL데이터베이스를 이용하기 때문에 아래 코드 작성
		try {
			//클래스 객체를 이용
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String uid = "c##root";
			String upw = "1234";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, uid, upw);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	//게시물 인덱스번호 마지막의 다음번호 가져오는 메소드
	public int getNext() {
		String sql = "select bID from bbs order by bID desc";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	
	//작성자 이름 가져오기
	public String getName(String userID) {
		
		String sql = "select userName from member where userID = ?";
		
		try {
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, userID);
		rs = pstmt.executeQuery();
		if (rs.next()) {
			return rs.getString(1);
		}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return ""; //데이터베이스 오류
	}
	
	//게시판 작성 로직
	public int write(String bTitle, String bContent, String userID) {
		// TODO Auto-generated method stub
		
		//Insert or Update와 같이 특정된 값을 변경하지만 값을 불러올 필요는 없는 로직들을 작성할때는
		//커넥션과 프리페어드스테이트먼트 2개 필요 ResultSet은 필요없다.
		//1. 커넥션 : 로드 된 드라이버 연결하는 객체
		//2. pstmt : sql문을 데이터베이스에 실행하는 객체
		
		try {
			//드라이버 매니저 클래스는. 데이터베이스에 맞는 외부 라이브러리인 JDBC를 다운 받아 연결해줘야 사용 가능.
//			connection = dataSource.getConnection();
//			String sql = "select ifnull(max(serial), 0)+1 from mvc_board"; LAST_INSERT_ID()+1
			int index = getNext();
			String name = getName(userID);
			String sql = "insert into BBS (bId, bName, bTitle, bContent, bHit, bGroup, bStep, bIndent, userID) values (?, ?, ?, ?, 0, ?, 0, 0, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, index);
			pstmt.setString(2, name);
			pstmt.setString(3, bTitle);
			pstmt.setString(4, bContent);
			pstmt.setInt(5, index);
			pstmt.setString(6, userID);
			
			int rn = pstmt.executeUpdate();
			return rn;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return -1;
	}
	
	//게시판 리스트 로드
	public ArrayList<BDto> list(int pageNum) {
		
		//특정된 값을 불러오는 로직 반드시 return값은 배열이며  제네릭을 사용
		//0. BTO : 빈즈와 같다 생성을 한다.
		//1. 커넥션 : 로드 된 드라이버 연결하는 객체
		//2. pstmt : SQL문을 데이터베이스에 실행하는 객체
		//3. RS : 
		ArrayList<BDto> dtos = new ArrayList<BDto>();
		String query = "select * from (select * from BBS where bID < ? order by bGroup DESC, BINDENT ASC) where ROWNUM <= 10";
		
		int getNext = getNext();
		System.out.println("listDAO getNext: " + getNext);
		System.out.println("listDAO pageNum: " + pageNum);
		
		try {
			//1.로드 된 JDBC 드라이버 연결하는 로직 order by bGroup desc, bStep asc
			//2. 연결한 커넥션의 메소드를 이용하며 인자값은 쿼리문이다.
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, getNext - (pageNum - 1) * 10);
			
			System.out.println("listDAO try getNext :" + (getNext - (pageNum - 1) * 10));
			//3. 특정된 쿼리문으로 가져온 데이터들을 RS변수에 담음.
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				int bId = rs.getInt("bId");
				String bName = rs.getString("bName");
				String bTitle = rs.getString("bTitle");
				String bContent = rs.getString("bContent");
				Timestamp bDate = rs.getTimestamp("bDate");
				int bHit = rs.getInt("bHit");
				int bGroup = rs.getInt("bGroup");
				int bStep = rs.getInt("bStep");
				int bIndent = rs.getInt("bIndent");
				String userID = rs.getString("userID");
				
				BDto dto = new BDto(bId, bName, bTitle, bContent, bDate, bHit, bGroup, bStep, bIndent, userID);
				dtos.add(dto);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return dtos;
	}
	
	//페이징처리
	public boolean nextPage(int pageNum) {
		
		String query = "select * from BBS where bID <= ? ";
		int getNext = getNext();
		System.out.println("DAO getNext : " + getNext);
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, getNext - (pageNum - 1) * 10);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				return true;
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return false;
	}
	
	//선택 된 게시물 보기
	public BDto contentView(String bId) {

		upHit(bId);
		
		String sql = "select * from BBS where bId = ?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bId);
			rs = pstmt.executeQuery();
			
			if(rs.next()){
				BDto dto = new BDto();
				dto.setbId(rs.getInt("bId"));
				dto.setbName(rs.getString("bName"));
				dto.setbTitle(rs.getString("bTitle"));
				dto.setbContent(rs.getString("bContent"));
				dto.setbDate(rs.getTimestamp("bDate"));
				dto.setbHit(rs.getInt("bHit"));
				dto.setbGroup(rs.getInt("bGroup"));
				dto.setbStep(rs.getInt("bStep"));
				dto.setbIndent(rs.getInt("bIndent"));
				dto.setUserID(rs.getString("userID"));
				return dto;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		return null;
	}
	
	//게시판 수정
	public void update(String bId, String bTitle, String bContent) {
		// TODO Auto-generated method stub
		
		
		try {
			
			String query = "update BBS set bTitle = ?, bContent = ? where bId = ?";
			pstmt = conn.prepareStatement(query);
			
			
			pstmt.setString(1, bTitle);
			pstmt.setString(2, bContent);
			pstmt.setInt(3, Integer.parseInt(bId));
			
			int rn = pstmt.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
	}
	
	//게시판 삭제
	public void delete(String bId) {
		// TODO Auto-generated method stub
		try {
			
			String query = "delete from BBS where bId = ?";
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, Integer.parseInt(bId));
			int rn = pstmt.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
	}
	
	//답글 보기?
	public BDto reply_view(String str) {
		// TODO Auto-generated method stub
		BDto dto = null;
		
		try {
			String query = "select * from BBS where bId = ?";
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, Integer.parseInt(str));
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				int bId = rs.getInt("bId");
				String bName = rs.getString("bName");
				String bTitle = rs.getString("bTitle");
				String bContent = rs.getString("bContent");
				Timestamp bDate = rs.getTimestamp("bDate");
				int bHit = rs.getInt("bHit");
				int bGroup = rs.getInt("bGroup");
				int bStep = rs.getInt("bStep");
				int bIndent = rs.getInt("bIndent");
				String userID = rs.getString("userID");
				
				dto = new BDto(bId, bName, bTitle, bContent, bDate, bHit, bGroup, bStep, bIndent, userID);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
		return dto;
	}
	
	
	public void reply(int bId, String bName, String bTitle, String bContent, int bGroup, int bStep, int bIndent, String userID) {
		// TODO Auto-generated method stub
		
		/* replyShape(bGroup, bIndent); */
		
		int getNext = getNext();
		try {
			String query = "insert into BBS (bId, bName, bTitle, bContent, bGroup, bStep, bIndent, userID) values (?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(query);
			
			pstmt.setInt(1, getNext);
			pstmt.setString(2, bName);
			pstmt.setString(3, bTitle);
			pstmt.setString(4, bContent);
			pstmt.setInt(5, bGroup);
			pstmt.setInt(6, bStep + 1);
			pstmt.setInt(7, bIndent + 1);
			pstmt.setString(8, userID);
			
			int rn = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
	}

	/*
	 * int idx = Integer.parseInt(request.getParameter("idx")); try { int ref = 0;
	 * int indent = 0; int step = 0; Connection conn =
	 * DriverManager.getConnection(url,id,pass); Statement stmt =
	 * conn.createStatement(); String sql =
	 * "SELECT REF, INDENT, STEP FROM board WHERE NUM=" + idx; ResultSet rs =
	 * stmt.executeQuery(sql); if(rs.next()) { ref = rs.getInt(1); indent =
	 * rs.getInt(2); step = rs.getInt(3); }
	 * 
	 */	
	
	
	//bindent ASC 기준으로 마지막 답글이 위로 정렬되게 끔 하는 로직
	private void replyShape(int strGroup, int bIndent) {
		// TODO Auto-generated method stub
		
		try {
			String query = "update BBS set BINDENT = BINDENT + 1 where bGroup = ? and bindent > ?";
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, strGroup);
			pstmt.setInt(2, bIndent);
			
			int rn = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} 
	}
	
	//조회수
	private void upHit(String bId) {
		// TODO Auto-generated method stub
		
		try {
			String query = "update BBS set bHit = bHit + 1 where bId = ?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, bId);
			
			int rn = pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
}
